export const environment = {
    production: true,
    firebase: {
        apiKey: 'AIzaSyAzIDrBYzDza9VT8WH11oBpyb-oTEddJ5A',
        authDomain: 'fcc-book-trading-91424.firebaseapp.com',
        databaseURL: 'https://fcc-book-trading-91424.firebaseio.com',
        projectId: 'fcc-book-trading-91424',
        storageBucket: '',
        messagingSenderId: '1057970477359'
    }
};
