export enum States {
    login,
    dashboard,
    library,
}
